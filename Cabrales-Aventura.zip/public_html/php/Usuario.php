<?php
require_once 'Conexion.php';
class Usuario extends Conexion
{
private $id;
private $pass;


public function __construct() //creamos el constructor , en php solo puedo tener uno
{
    parent::__construct();

}

// Setters y Getters
public function setId($id)
{
    $this->id = $id;
}

public function setPass($pass)
{
    $this->pass = $pass;
}


// Ahora definimos las funciones que los usuarios podran utilizar
function listadoUsuarios()
{
    $usuarios= array();
    $consulta = "SELECT * FROM usuario";
    $stmt = $this->conexion->prepare($consulta);
    try {
        $stmt->execute();
        while(($fila=$stmt-> fetch())!=null){
            array_push($usuarios,$fila);
        }
    } catch (PDOException $ex) {
        die("Error al recuperar usuarios: " . $ex->getMessage());
    }
    //$this->conexion = null;
    return $usuarios;
}
//añadir usuario
function crearUsuario()
{
    $insert = "insert into usuario(id,pass) values( :d, :n)";
    $stmt = $this->conexion->prepare($insert);
    try {
        $stmt->execute([
            
            ':d' => $this->id,
            ':n' => $this->pass,
        ]);
    } catch (PDOException $ex) {
        die("Ocurrio un error al añadir el usuario: " . $ex->getMessage());
    }
}
        //Eliminar usuario
        function eliminarUsuario()
        {
            $borrar = "delete from usuario where id=:i";
            $stmt = $this->conexion->prepare($borrar);
            try {
                $stmt->execute([':i' => $this->id]);
            } catch (PDOException $ex) {
                die("Ocurrio un error al borrar usuario: " . $ex->getMessage());
            }
        }

//funcion cambiar contraseña
function changePass()
{
    $update = "update usuario set pass=:p";
    $stmt = $this->conexion->prepare($update);
            try {
                $stmt->execute([
                    ':p' => $this->pass
                ]);
            } catch (PDOException $ex) {
                die("Ocurrio un error al actualizar contraseña: " . $ex->getMessage());
            }
}
   // Funcion para comprobar que el nombre de usuario no se repite
   function existsName($id)
   {
    try{
       if ($this->id == null) {
           $consulta = "select count(nombre) from usuario where nombre=:n";
           $stmt = $this->conexion->prepare($consulta);
           $stmt->execute([':n' => $id]);
       } 
     
    
       } catch (PDOException $ex) {
           die("Error al comprobar el id: " . $ex->getMessage());
       }
       if ($stmt->rowCount() == 0) return false; //No existe
       return true; //existe

   }

   function validarLogeo(){

    // hacemos las consulta la base pidiendo toda la informacion de la tabla usuarios y le decimos que la variable username (introducida por usuario tiene que ser un id de la tabla)
    $query = $dwes->prepare("SELECT * FROM usuario WHERE id ='$username'");
    $stmt = $this->conexion->prepare($dwes);
    // lo ejecutamos                 
    $query->execute();
    //generamos un array con los datos para que conpruebe que el usuario existe
    $result = $query->fetch(PDO::FETCH_ASSOC);
//comprobamos que todo esta bien
    if (!$result) {
        echo '<p class="error">El usuario introducido no es valido.</p>';
    } 
    else 
    {
        if ($password==$result['pass']) {
            $_SESSION['user_id'] = $result['idUsuario'];
            header("location: index.html");
        } else {
            echo '<p class="error">La contraseña introducida no es valida.</p>';
        }
    }
   }
}