<?php
// Creamos la clase de conexión
class Conexion
{
    private $host;
    private $db;
    private $user;
    private $pass;
    private $dsn;
    protected $conexion;

    // Constructor de la clase
    public function __construct()
    {
        $this->host = "localhost";
        $this->db = "u417942024_aventura"; // Sin espacios en blanco
        $this->user = "u417942024_jorge";
        $this->pass = "Tordin555";
        $this->dsn = "mysql:host={$this->host};dbname={$this->db};charset=utf8mb4";
        $this->crearConexion();
       
    }

    // Método para crear la conexión
    public function crearConexion()
    {
        try {
            $this->conexion = new PDO($this->dsn, $this->user, $this->pass);
            $this->conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            // echo "Conexión realizada con éxito";
        } catch (PDOException $ex) {
            die("Error en la conexión: mensaje: " . $ex->getMessage());
        }
        return $this->conexion;
    }
}