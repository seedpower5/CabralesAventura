<?php
require_once 'Conexion.php';
class Categoria extends Conexion
{
private $id_cat;
private $descripcion;
private $estado;


public function __construct() //creamos el constructor , en php solo puedo tener uno
{
    parent::__construct();

}

// Setters 
public function setId_Cat($id_cat)
{
    $this->id_cat = $id_cat;
}
public function setDescripcion($descripcion)
{
    $this->descripcion= $descripcion;
}
public function setEstado($estado)
{
    $this->estado = $estado;
}
//Getters
public function getId_Cat()
{
    return $this->id_cat;
}
public function getDescripcion()
{
    return $this->descripcion;
}
public function getEstado()
{
    return $this->estado;
}
 //Funciones de base datos
 function listadoCategorias()
 {
     $categorias= array();
     $consulta = "SELECT * FROM categoria ";
     $stmt = $this->conexion->prepare($consulta);
     try {
         $stmt->execute();
         while(($fila=$stmt-> fetch())!=null){
             array_push($categorias,$fila);
         }
     } catch (PDOException $ex) {
         die("Error al recuperar categorias: " . $ex->getMessage());
     }
     //$this->conexion = null;
     return $categorias;
 }
function listadoCategoriasHabilitadas()
{
    $categorias= array();
    $consulta = "SELECT * FROM categoria where estado=0";
    $stmt = $this->conexion->prepare($consulta);
    try {
        $stmt->execute();
        while(($fila=$stmt-> fetch())!=null){
            array_push($categorias,$fila);
        }
    } catch (PDOException $ex) {
        die("Error al recuperar categorias: " . $ex->getMessage());
    }
    //$this->conexion = null;
    return $categorias;
}
function listadoCategoriasDeshabilitadas()
{
    $categorias= array();
    $consulta = "SELECT * FROM categoria where estado=1";
    $stmt = $this->conexion->prepare($consulta);
    try {
        $stmt->execute();
        while(($fila=$stmt-> fetch())!=null){
            array_push($categorias,$fila);
        }
    } catch (PDOException $ex) {
        die("Error al recuperar categorias: " . $ex->getMessage());
    }
    //$this->conexion = null;
    return $categorias;
}
function deshabilitarCategoria($id_cat)
{
    $consulta = "UPDATE categoria SET estado=1 WHERE id_cat=:id_cat";
    $stmt = $this->conexion->prepare($consulta);
    $stmt->bindParam(':id_cat', $id_cat, PDO::PARAM_INT);
    try {
        $stmt->execute();
    } catch (PDOException $ex) {
        die("Error al deshabilitar categoria: " . $ex->getMessage());
    }
}
function habilitarCategoria($id_cat)
{
    $consulta = "UPDATE categoria SET estado=0 WHERE id_cat=:id_cat";
    $stmt = $this->conexion->prepare($consulta);
    $stmt->bindParam(':id_cat', $id_cat, PDO::PARAM_INT);
    try {
        $stmt->execute();
    } catch (PDOException $ex) {
        die("Error al habilitar categoria: " . $ex->getMessage());
    }
}
  //Eliminar categoria
  function eliminarCategoria()
  {
      $borrar = "delete from categoria where id_cat=:i";
      $stmt = $this->conexion->prepare($borrar);
      try {
          $stmt->execute([':i' => $this->id_cat]);
      } catch (PDOException $ex) {
          die("Ocurrio un error al borrar categoria: " . $ex->getMessage());
      }
  }
  //añadir categoria
function crearCategoria()
{
    $insert = "insert into categoria(descripcion,estado) values( :d, :n)";
    $stmt = $this->conexion->prepare($insert);
    try {
        $stmt->execute([
            ':d' => $this->descripcion,
            ':n' => $this->estado
        ]);
    } catch (PDOException $ex) {
        die("Ocurrio un error al crear el categoria: " . $ex->getMessage());
    }
}
}