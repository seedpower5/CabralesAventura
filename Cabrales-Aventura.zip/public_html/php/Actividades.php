<?php
require_once 'Conexion.php';
class Actividades extends Conexion
{
private $id_actividad;
private $descripcion;
private $nombre;
private $precio;
private $id_categoria;
private $dificultad;
private $estado;
private $imagen;
public function __construct() //creamos el constructor , en php solo puedo tener uno
{
    parent::__construct();

}

// Setters 
public function setId_Actividad($id_actividad)
{
    $this->id_actividad = $id_actividad;
}

public function setDescripcion($descripcion)
{
    $this->descripcion = $descripcion;
}

public function setNombre($nombre)
{
    $this->nombre = $nombre;
}

public function setPrecio($precio)
{
    $this->precio = $precio;
}

public function setId_Categoria($id_categoria)
{
    $this->id_categoria = $id_categoria;
}
public function setDificultad($dificultad)
{
    $this->dificultad = $dificultad;
}
public function setEstado($estado)
{
    $this->estado = $estado;
}
public function setImagen($imagen)
{
    $this->imagen = $imagen;
}
//GETTERS
public function getId_Actividad()
{
    return $this->id_actividad;
}
public function getDescripcion()
{
    return $this->descripcion;
}
public function getNombre()
{
    return $this->nombre;
}
public function getPrecio()
{
    return $this->precio;
}
public function getId_Categoria()
{
    return $this->categoria;
}
public function getDificultad()
{
    return $this->dificultad;
}
public function getEstado()
{
    return $this->estado;
}
public function getImagen()
{
    return $this->imagen;
}
//FUNCIONES
//Mostrar actividad siempre que el estado sea 1 que lo que habilita la actividad
        
        function listadoActividades()
        {
            $actividades= array();
            $consulta = "SELECT * FROM actividades ";
            $stmt = $this->conexion->prepare($consulta);
            try {
                $stmt->execute();
                while(($fila=$stmt-> fetch())!=null){
                    array_push($actividades,$fila);
                }
            } catch (PDOException $ex) {
                die("Error al recuperar actividades: " . $ex->getMessage());
            }
            //$this->conexion = null;
            return $actividades;
        }
        function listadoCarreras()
        {
            $actividades= array();
            $consulta = "SELECT * FROM actividades where id_categoria=5 ";
            $stmt = $this->conexion->prepare($consulta);
            try {
                $stmt->execute();
                while(($fila=$stmt-> fetch())!=null){
                    array_push($actividades,$fila);
                }
            } catch (PDOException $ex) {
                die("Error al recuperar actividades: " . $ex->getMessage());
            }
            //$this->conexion = null;
            return $actividades;
        }
 

 
//Eliminar actividad
        function eliminarActividad()
        {
            $borrar = "delete from actividades where id_actividad=:i";
            $stmt = $this->conexion->prepare($borrar);
            try {
                $stmt->execute([':i' => $this->id_actividad]);
            } catch (PDOException $ex) {
                die("Ocurrio un error al borrar la actividad: " . $ex->getMessage());
            }
        }

        function crearActividad()
        {
            $insert = "INSERT INTO actividades (descripcion, nombre, precio, id_categoria, dificultad, estado, imagen) VALUES (:d, :n, :p, :c, :a, 1, :e)";
            $stmt = $this->conexion->prepare($insert);
            try {
                $stmt->execute([
                    ':d' => $this->getDescripcion(),
                    ':n' => $this->getNombre(),
                    ':p' => $this->getPrecio(),
                    ':c' => $this->getId_Categoria(),
                    ':a' => $this->getDificultad(),
                    ':e' => $this->getImagen()
                ]);
            } catch (PDOException $ex) {
                die("Ocurrió un error al añadir la actividad: " . $ex->getMessage());
            }
        }
//Modificar actividad
        function modificarActividad()
        {
            $insert = "insert into actividades(id_actividad,descripcion,nombre,precio,id_categoria)";
            $stmt = $this->conexion->prepare($insert);
            try {
                $stmt->execute([
                    $id_actividad => $this->id_actividad,
                    $descripcion => $this->descripcion,
                    $nombre => $this->nombre,
                    $precio => $this->precio,
                    $id_categoria => $this->id_categoria
                ]);
            } catch (PDOException $ex) {
                die("Error modificar actividad: " . $ex->getMessage());
            }
            return $stmt->fetchAll(PDO::FETCH_OBJ);//devuelve una tabla con todos los jugadores y sus puestos
        }

        //seleccionamos el nombre de la actividad segun el id pera el formulario
        function selectedActividad($id_actividad)
        {

           // if($this->conexion==null){echo "FALLA LA CONEXION";}
           
            $consulta = "SELECT * FROM actividades where id_actividad=:a";
            // echo "****".$consulta."*****";
            $stmt = $this->conexion->prepare($consulta);
            try {
                $stmt->execute([':a' => $id_actividad]);
                
                $fila=$stmt-> fetch();
            } catch (PDOException $ex) {
                die("Error al recuperar actividad: " . $ex->getMessage());
            }
            return $fila['nombre'];
        }
        //metdo para recuperar listado por categoria
        function seleccionarActividadPorCategoria($id_categoria) {

            $consulta = "SELECT * FROM actividades WHERE id_categoria=:cat_id";
            
            try {
                $stmt = $this->conexion->prepare($consulta);
                $stmt->bindParam(':cat_id', $id_categoria, PDO::PARAM_INT);
                $stmt->execute();
                $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $ex) {
                die("Error al recuperar actividades por categoría: " . $ex->getMessage());
            }
        
            return $resultados;
        }

//seleccionar id_actividad en base al nombre_actividad
public function getIdActividad($nombre_actividad) {
    $sql = "SELECT id_actividad FROM actividades WHERE nombre = :nombre_actividad";
    $stmt = $this->conexion->prepare($sql);
    $stmt->execute([':nombre_actividad' => $nombre_actividad]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['id_actividad'];
}


}
/*
$miActividad = new Actividades();
  print_r($miActividad->selectedActividad(3));*/

/*
$miActividad = new Actividades();
  print_r($miActividad->selectedActividad(3));*/
