<?php
session_start();

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Menu Administrador</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="../css/temas.css">
		<link rel="stylesheet" href="../css/bootstrap.css">
		<link rel="stylesheet" href="../css/w3.css">
		<link rel="stylesheet" href="../css/estilo.css"> 
		<link rel="shortcut icon" href="../fotos/logos/logo.png" type="image/x-icon">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	
    <body>

		<nav class="w3-sidebar w3-bar-block w3-card w3-animate-left w3-center" style="display:none" id="mySidebar">
			<a href="../../menu.php" class="w3-bar-item w3-button">Menu</a>
			<a href="../prestamos.php" class="w3-bar-item w3-button">Prestamos</a>
			<a href="../historial/historial.php" class="w3-bar-item w3-button">Historial</a>
			<a href="../mostrar-datos.php" class="w3-bar-item w3-button">Inventario</a>
			<a href="../logout.php" class="w3-bar-item w3-button">Cerrar Sesion</a>
			<a href="menu-administrador.php" class="w3-bar-item w3-button">Menu Administrador</a> 
			<button class="w3-bar-item w3-button" onclick="w3_close()">Close <i class="fa fa-remove"></i></button>
		</nav>
	  
		<header class="cabecera" id="myHeader">
			
			<div class="w3-center">
			<a href="../index.html"><img class="logo" src="../fotos/logos/logo.png" alt="" width="100" height="100"/></a>
				<h1 class="w3-xxxlarge w3-animate-bottom"><b>MENU</b></h1>
				<h1 class="w3-xxxlarge w3-animate-bottom"><b>ADMINISTRADOR</b></h1>
				<div class="w3-padding-16"/>
			
			</div>
		</header>
		
	  
		</header>	  
		<div class="w3-row-padding w3-center w3-margin-top">

			<a href="../Administracion/crearRuta.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Añadir Rutas</b></h3>
						<br>
						<i class="fa fa-plus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/crearUsuario.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Añadir Usuarios</b></h3>
						<br>
						<i class="fa fa-plus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/crearCategoria.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Añadir Categoria</b></h3>
						<br>
						<i class="fa fa-plus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/eliminarRuta.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Eliminar Rutas</b></h3>
						<br>
						<i class="fa fa-minus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/eliminarUsuario.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Eliminar Usuarios</b></h3>
						<br>
						<i class="fa fa-minus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/eliminarReserva.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Eliminar Reserva</b></h3>
						<br>
						<i class="fa fa-minus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/habilitarCategoria.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Habilitar Categoria</b></h3>
						<br>
						<i class="fa fa-check-square-o w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>

			<a href="../Administracion/deshabilitarCategoria.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>Deshabilitar Categoria</b></h3>
						<br>
						<i class="fa fa-minus-square-o w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
			
			<a href="../Administracion/eliminarCategoria.php">
				<div class="w3-third">
					<div class="w3-card w3-container" style="min-height:18vh">
						<h3><b>EliminarCategoria</b></h3>
						<br>
						<i class="fa fa-minus-square w3-margin-bottom w3-text-theme" style="font-size:12vh"></i>
					</div>
				</div>
			</a>
		</div>

   </body>
</html>