<?php
require_once 'Conexion.php';
class Reservas extends Conexion
{
    private $id;
    private $nombre;
    private $apellido;
    private $correo;
    private $telefono;
    private $id_actividad;
    private $nombre_actividad;
    private $fecha_inicio;
    private $fecha_final;
    private $num_personas; // Nuevo campo agregado

    public function __construct()
    {
        parent::__construct();
    }

// Setters 
public function setId($id)
{
    $this->id = $id;
}
// Setters 
public function setNombre($nombre)
{
    $this->nombre = $nombre;
}
// Setters
public function setApellido($apellido)
{
    $this->apellido = $apellido;
}
// Setters
public function setCorreo($correo)
{
    $this->correo = $correo;
}
// Setters
public function setTelefono($telefono)
{
    $this->telefono = $telefono;
}
// Setters
public function setIdActividad($id_actividad)
{
    $this->id_actividad = $id_actividad;
}

// Setters
public function setNombreActividad($nombre_actividad)
{
    $this->nombre_actividad= $nombre_actividad;
}
// Setters 
public function setFechaInicio($fecha_inicio)
{
    $this->fecha_inicio= $fecha_inicio;
}// Setters 
public function setFechaFinal($fecha_final)
{
    $this->fecha_final = $fecha_final;
}
 // Setters
 public function setNumPersonas($num_personas)
 {
     $this->num_personas = $num_personas;
 }



//Getters
public function getId()
{
    return $this->id;
}
//Getters
public function getNombre()
{
    return $this->nombre;
}
//Getters
public function getApellido()
{
    return $this->apellido;
}
//Getters
public function getCorreo()
{
    return $this->correo;
}
//Getters
public function getTelefono()
{
    return $this->telefono;
}
//Getters
public function getIdActividad()
{
    return $this->id_actividad;
}
//Getters
public function getNombreActividad()
{
    return $this->nombre_actividad;
}
//Getters
public function getFechaInicio()
{
    return $this->fecha_inicio;
}
//Getters
public function getFechaFinal()
{
    return $this->fecha_final;
}
 // Getters
 public function getNumPersonas()
 {
     return $this->num_personas;
 }

// Ahora definimos las funciones que los usuarios podran utilizar
//añadir reserva siempre y cuando no exista una reserva ya ese dia
function crearReserva()
{  
    // Variable para controlar si se muestra el mensaje de éxito
    $funciona = true;

    // Verificar si ya existe una reserva en la misma fecha
    $select = "SELECT COUNT(*) FROM reservas WHERE fecha_inicio = :g";
    $stmtSelect = $this->conexion->prepare($select);
    try {
        $stmtSelect->execute([
            ':g' => $this->fecha_inicio
        ]);
        $count = $stmtSelect->fetchColumn();
        if ($count > 0) {
            // Ya existe una reserva en la misma fecha, mostrar mensaje de error
            $funciona = false;
            echo "Lo sentimos, pero ese día ya fue seleccionado por otro cliente.";
            return;
        }
    } catch (PDOException $ex) {
        $funciona = false;
        die("Ocurrió un error al verificar la reserva: " . $ex->getMessage());
    }
   
    // Insertar la reserva si no existe una reserva en la misma fecha
    $insert = "INSERT INTO reservas(nombre,apellido,correo,telefono,nombre_actividad,fecha_inicio,fecha_final, id_actividad, num_personas) VALUES (:a, :b, :c, :d, :f, :g, :h, :i, :j)";
        $stmt = $this->conexion->prepare($insert);
        try {
            $stmt->execute([
                ':a' => $this->nombre,
                ':b' => $this->apellido,
                ':c' => $this->correo,
                ':d' => $this->telefono,
                ':f' => $this->nombre_actividad,
                ':g' => $this->fecha_inicio,
                ':h' => $this->fecha_final,
                ':i' => $this->id_actividad,
                ':j' => $this->num_personas // Agregamos el valor de num_personas
            ]);

            // ...

        } catch (PDOException $ex) {
            $funciona = false;
            die("Ocurrió un error al crear la reserva: " . $ex->getMessage());
        }

    if ($funciona) {
        echo "Reserva creada correctamente<br>";
        echo "Contactaremos con usted vía teléfono o correo electrónico para confirmación de la misma<br>";
        echo "Gracias por elegirnos";
    }
}

function listadoReservas()
{
    $reservas= array();
    $consulta = "SELECT * FROM reservas";
    $stmt = $this->conexion->prepare($consulta);
    try {
        $stmt->execute();
        while(($fila=$stmt-> fetch())!=null){
            array_push($reservas,$fila);
        }
    } catch (PDOException $ex) {
        die("Error al recuperar reservas: " . $ex->getMessage());
    }
    //$this->conexion = null;
    return $reservas;
}
function eliminarReserva()
{
$borrar = "delete from reservas where id=:i";
$stmt = $this->conexion->prepare($borrar);
try {
$stmt->execute([':i' => $this->id]);
} catch (PDOException $ex) {
die("Ocurrio un error al borrar la reserva: " . $ex->getMessage());
    }
}
}