<?php
require_once 'Conexion.php';

class Carreras extends Conexion
{
    private $id_carrera;
    private $descripcion;
    private $nombre;
    private $precio;
    private $km;
    private $plazasReservadas;
    private $plazasDisponibles;

    public function __construct()
    {
        parent::__construct();
    }
    public function setIdCarrera($id_carrera)
    {
        $this->id_carrera = $id_carrera;
    }

    public function setDescripcion($descripcion)
    {
        $this->descripcion = $descripcion;
    }

    public function setNombre($nombre)
    {
        $this->nombre = $nombre;
    }

    public function setPrecio($precio)
    {
        $this->precio = $precio;
    }

    public function setKm($km)
    {
        $this->km = $km;
    }

    public function setPlazasReservadas($plazasReservadas)
    {
        $this->plazasReservadas = $plazasReservadas;
    }

    public function setplazasDisponibles($plazasDisponibles)
    {
        $this->plazasDisponibles = $plazasDisponibles;
    }

    public function getId_Carrera()
    {
        return $this->id_carrera;
    }

    public function getDescripcion()
    {
        return $this->descripcion;
    }

    public function getNombre()
    {
        return $this->nombre;
    }

    public function getPrecio()
    {
        return $this->precio;
    }

    public function getKm()
    {
        return $this->km;
    }

    public function getPlazasReservadas()
    {
        return $this->plazasReservadas;
    }

    public function getplazasDisponibles()
    {
        return $this->plazasDisponibles;
    }

    public function selectedCarrera($id_carrera)
    {
        $consulta = "SELECT * FROM carreras WHERE id_carrera = :a";
        $stmt = $this->conexion->prepare($consulta);

        try {
            $stmt->execute([':a' => $id_carrera]);
            $fila = $stmt->fetch();
        } catch (PDOException $ex) {
            die("Error al recuperar carrera: " . $ex->getMessage());
        }

        return $fila['nombre'];
    }

    public function listadoCarreras()
    {
        $carreras = array();
        $consulta = "SELECT * FROM carreras WHERE estado = 0";
        $stmt = $this->conexion->prepare($consulta);

        try {
            $stmt->execute();

            while (($fila = $stmt->fetch()) != null) {
                array_push($carreras, $fila);
            }
        } catch (PDOException $ex) {
            die("Error al recuperar carreras: " . $ex->getMessage());
        }

        return $carreras;
    }

    public function eliminarCarrera()
    {
        $borrar = "DELETE FROM carreras WHERE id_carrera = :i";
        $stmt = $this->conexion->prepare($borrar);

        try {
            $stmt->execute([':i' => $this->id_carrera]);
        } catch (PDOException $ex) {
            die("Ocurrió un error al borrar la carrera: " . $ex->getMessage());
        }
    }
      function crearCarrera()
        {
            $insert = "insert into carreras(descripcion,nombre,precio,km,plazasReservadas,plazasDisponibles) values( :d, :n, :p, :c,:a,:b)";
            $stmt = $this->conexion->prepare($insert);
            try {
                $stmt->execute([
                    
                    ':d' => $this->descripcion,
                    ':n' => $this->nombre,
                    ':p' => $this->precio,
                    ':c' => $this->km,
                    ':a' => $this->plazasReservadas,
                    ':b' => $this->plazasDisponibles,
                   
                ]);
            } catch (PDOException $ex) {
                die("Ocurrio un error al añadir el carrera: " . $ex->getMessage());
            }
        }
        //seleccionar id_actividad en base al nombre_actividad
         function getIdCarrera($nombre_carrera)
        {
            $sql = "SELECT id_carrera FROM Carreras WHERE nombre = :nombre_carrera";
            $stmt = $this->conexion->prepare($sql);
            $stmt->execute([':nombre_carrera' => $nombre_carrera]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row['id_carrera'];
        }
        public function obtenerPlazasLibres($nombre_carrera)
        {
            $id_carrera = $this->getIdCarrera($nombre_carrera);
            $consulta = "SELECT plazasDisponibles, plazasReservadas FROM carreras WHERE id_carrera = :id";
            $stmt = $this->conexion->prepare($consulta);
        
            try {
                $stmt->execute([':id' => $id_carrera]);
                $fila = $stmt->fetch();
                if ($fila) {
                    $plazasDisponibles = $fila['plazasDisponibles'];
                    $plazasReservadas = $fila['plazasReservadas'];
        
                    $plazasLibres = $plazasDisponibles - $plazasReservadas;
        
                    return $plazasLibres;
                } else {
                    // No se encontró la carrera
                    return null;
                }
            } catch (PDOException $ex) {
                // Error al ejecutar la consulta
                error_log("Error al obtener plazas libres: " . $ex->getMessage());
                return null;
            }
        }

        public function crearReserva($nombre_carrera)
        {
            // Obtener el ID de la carrera
            $id_carrera = $this->getIdCarrera($nombre_carrera);
        
            // Obtener las plazas disponibles y reservadas
            $consulta = "SELECT plazasDisponibles, plazasReservadas FROM carreras WHERE id_carrera = :id";
            $stmt = $this->conexion->prepare($consulta);
        
            try {
                $stmt->execute([':id' => $id_carrera]);
                $fila = $stmt->fetch();
        
                if ($fila) {
                    $plazasDisponibles = $fila['plazasDisponibles'];
                    $plazasReservadas = $fila['plazasReservadas'];
        
                    // Verificar si hay plazas disponibles
                    if ($plazasDisponibles > $plazasReservadas) {
                        // Actualizar el número de plazas reservadas
                        $plazasReservadas++;
        
                        // Actualizar el número de plazas disponibles
                        $plazasDisponibles--;
        
                        // Guardar los nuevos valores en la base de datos
                        $actualizarPlazas = "UPDATE carreras SET plazasReservadas = :reservadas, plazasDisponibles = :disponibles WHERE id_carrera = :id";
                        $stmt = $this->conexion->prepare($actualizarPlazas);
                        $stmt->execute([':reservadas' => $plazasReservadas, ':disponibles' => $plazasDisponibles, ':id' => $id_carrera]);
        
                        // Insertar los datos de la reserva en la tabla reservascarreras
                        $insertarReserva = "INSERT INTO reservascarreras (nombre, apellido, correo, telefono, id_carrera, nombre_carrera) VALUES (:nombre, :apellido, :correo, :telefono, :id_carrera, :nombre_carrera)";
                        $stmt = $this->conexion->prepare($insertarReserva);
                        $stmt->execute([
                            ':nombre' => $_POST['nombre'],
                            ':apellido' => $_POST['apellido'],
                            ':correo' => $_POST['correo'],
                            ':telefono' => $_POST['telefono'],
                            ':id_carrera' => $id_carrera,
                            ':nombre_carrera' => $nombre_carrera
                        ]);
        
                        echo "Reserva creada con éxito.";
                    } else {
                        echo "No hay plazas disponibles para esta carrera.";
                    }
                } else {
                    echo "La carrera no existe.";
                }
            } catch (PDOException $ex) {
                echo "Error al crear la reserva: " . $ex->getMessage();
            }
        }
    }