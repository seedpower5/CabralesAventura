<?php
include_once "Actividades.php"; 
include_once "Reservas.php"; 

$miActividad = new Actividades();
$actividades = $miActividad->listadoActividades();

if (isset($_POST['submit'])) {
  $reserva = new Reservas();
  
  $reserva->setNombre($_POST['nombre']);
  $reserva->setApellido($_POST['apellido']);
  $reserva->setCorreo($_POST['correo']);
  $reserva->setTelefono($_POST['telefono']);
  
  $nombre_actividad = $_POST['actividad_seleccionada'];
  $id_actividad = $miActividad->getIdActividad($nombre_actividad);
  
  $reserva->setIdActividad($id_actividad);
  $reserva->setNombreActividad($nombre_actividad);
  
  $reserva->setFechaInicio($_POST['fecha_inicio']);
  $reserva->setFechaFinal($_POST['fecha_final']);

  $reserva->setNumPersonas($_POST['num_personas']);

  $reserva->crearReserva();

  exit();
} else {
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../css/formularioStyle.css">
  <script src="../js/Formulario.js"></script>
  <title> Reservas</title>
  <link rel="shortcut icon" href="../fotos/logos/logo.png" type="image/x-icon">
</head>
<body>
   <!-- formulario de la pagina web donde el usuario manda sus datos parealizar una reserva -->

   <!-- en caso de que no se realize el acceso desde el boton reserva el que estara marcado por el formulario sera el cueton-->
   <?php 
   if(!isset($_GET['reserva'])){
    $_GET['reserva']=4 ;

   }
   $actividad=$miActividad->selectedActividad($_GET['reserva']);
  //echo "***".$actividad."****";
   ?>
   <!-- codigo para recopilar la informacion del formulario y mandarlo por correo  -->

   <form class="w3-animate-right w3-large " action="Formulario.php" method="POST" id="formulario" onsubmit="return actualizarNumPersonas();">
					
  <section class="form-register">
    
    <h4> Reservas</h4>
    <input class="controls" type="text" name="nombre" id="nombre" placeholder="Ingrese su Nombre">
    <input class="controls" type="text" name="apellido" id="apellido" placeholder="Ingrese su Apellido">
    <input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo">
    <input class="controls" type="number" name="telefono" id="telefono" placeholder="Ingrese su telefono">
    <div class= "controls">
    <label>Numero Personas:</label>
    <input class="num_personas" type="number" name="num_personas" id="num_personas">
    </div>
    <div class= "controls">  
      <label>Selecciona tipo actividad:</label>
      <select  type= "text" name="actividad_seleccionada" id="actividad_seleccionada" required>
  <!-- accemos un foreach que seleccione el nombre de la actividad y lo marque como seleccionado -->
      <?php 
            foreach($actividades as $act){
              echo "<option";
                if($actividad==$act['nombre']){echo " selected=selected";}
              echo">".$act['nombre'];
              echo "</option>";
            }
        ?>

      </select>
  </div>
<!-- calendario que conecta con la base de datos y reserva dias de actividad -->
  Fecha Inicio<input class="controls" type="date" name="fecha_inicio" id="fecha_inicio">
  Fecha Final<input class="controls" type="date" name="fecha_final" id="fecha_final">
  
  <input type="radio" name="condiciones" value="condiciones" required>Acepta Terminos y Condiciones <br>
  <input class="botons" type="submit" value="enviar" name="submit">
  <p><a href="../FuncionamientoReservas.html">¿Como Funcionan Las Reservas?</a></p>
    <p><a href="../index.html">Volver a página principal</a></p>
  </section>
  </form>
</body>
</html>