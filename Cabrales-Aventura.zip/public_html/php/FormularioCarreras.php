<?php
require_once 'Carreras.php';

$miCarrera = new Carreras();
$carreras = $miCarrera->listadoCarreras();

if (isset($_POST['submit'])) {
    $nombreCarrera = $_POST['carrera_seleccionada'];

    $miCarrera->crearReserva($nombreCarrera);

    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="../css/formularioCarrerasStyle.css">
    <script src="../js/FormularioCarreras.js"></script>
    <title>Reservas</title>
    <link rel="shortcut icon" href="../fotos/logos/logo.png" type="image/x-icon">
</head>

<body>
    <!-- formulario de la pagina web donde el usuario manda sus datos para realizar una reserva -->

    <!-- código para recopilar la información del formulario y mandarlo por correo -->
    <form class="w3-animate-right w3-large" action="formularioCarreras.php" method="POST">
        <section class="form-register">
            <h4>Reservas</h4>
            <input class="controls" type="text" name="nombre" id="nombre_usuario" placeholder="Ingrese su Nombre">
            <input class="controls" type="text" name="apellido" id="apellido" placeholder="Ingrese su Apellido">
            <input class="controls" type="email" name="correo" id="correo" placeholder="Ingrese su Correo">
            <input class="controls" type="number" name="telefono" id="telefono" placeholder="Ingrese su teléfono">
            <div class="controls">
                <label>Selecciona carrera:</label>
                <select type="text" name="carrera_seleccionada" id="carrera_seleccionada" required>
                    <!-- accedemos a las carreras obtenidas y las mostramos en el desplegable -->
                    <?php
                    foreach ($carreras as $carr) {
                        echo "<option value='" . $carr['nombre'] . "'>" . $carr['nombre'] . "</option>";
                    }
                    ?>
                </select>
            </div>
            <input type="radio" name="condiciones" value="condiciones" required>Acepta Terminos y Condiciones<br>
            <input class="botons" type="submit" value="Enviar" name="submit">
            <p><a href="../FuncionamientoReservas.html">¿Cómo Funcionan Las Reservas?</a></p>
            <p><a href="../index.html">Volver a la página principal</a></p>
        </section>
    </form>

</body>
</html>
