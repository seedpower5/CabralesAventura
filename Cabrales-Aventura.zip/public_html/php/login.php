<?php
// iniciamos sesion para que se guarden los datos
session_start();
 // incluimos el archivo de conexion y creamos una nueva conexion
                include_once "Conexion.php"; 
                $conexion = new Conexion();
                $dwes = $conexion->crearConexion();

                // creamos las variables que contienen la informacion que el usuario nos da
                if (isset($_POST['login'])) {
                    $username = $_POST['username'];
                    $password = md5($_POST['password']); // encriptamos la contraseña del usuario

                    // hacemos las consulta la base pidiendo toda la informacion de la tabla usuarios y le decimos que la variable username (introducida por usuario tiene que ser un id de la tabla)
                    $query = $dwes->prepare("SELECT * FROM usuario WHERE id = :username");
                    $query->bindParam(":username", $username);
                    $query->execute();
                    $result = $query->fetch(PDO::FETCH_ASSOC);

                    if (!$result) {
                        echo '<p class="error">El usuario introducido no es valido.</p>';
                    } else {
                        if ($password == $result['pass']) {
                            $_SESSION['user_id'] = $result['idUsuario'];
                            header("location: ./Administracion.php");
                        } else {
                            echo '<p class="error">La contraseña introducida no es valida.</p>';
                        }
                    }
                }   
?>
<!DOCTYPE html>
<html lang="es-ES">
<head>
    <title>Iniciar sesión</title>
    <meta charset="UTF-8"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/solid.css">
    <script src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <script src="../js/bootstrap.js"></script>
    <link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/bootstrap.css.map">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="shortcut icon" href="../fotos/logos/logo.png" type="image/x-icon">
    <link rel="stylesheet" type="text/css" href="../css/login.css">
</head>
<body >
 <!-- Navegador de la pagina web -->
 <nav class="nav nav-pills nav-fill bg-dark">
          <a class="nav-item nav-link" href="../index.html">Inicio</a>
          <a class="nav-item nav-link" href="../listadoActividades.php">Actividades</a>
          <a class="nav-item nav-link" href="../trails.php">Carreras</a>
          <a class="nav-item nav-link" href="Formulario.php">Reservas</a>
      </nav>
    <main>
        <div class="container">
                    <div class="modal-dialog text-center">
                        <div class="col-lg-12 main-section">
                            <div class="modal-content" style='background-color: #343a40!important;'>
                                <div class="col-12 imagen">
                                    <img class="logo" src="../fotos/logos/logo.png"/>
                                </div>
                                <form class="col-12" action="login.php" method="post">
                                    <div class="form-group" id="user-group">
                                        <input type="text" class="form-control" placeholder="Nombre Usuario" name="username" required style="border: 2px solid black;"/>
                                    </div>
                                    <div class="form-group" id="contrasena-group">
                                        <input type="password" class="form-control" placeholder="Contraseña" name="password" required style="border: 2px solid black;"/>
                                    </div>
                                    <button id="botonlogin" name="login" type="submit" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i>Iniciar sesión</button>
                                </form>
                                <div class="col-12 redireccion_solicitud">
                                    <a href="solicitar_usuario.html">¿Has olvidado tu contraseña?</a>
                                </div>
                                <div class="col-12 redireccion_pagina">
                                    <a href="Administracion.php"></a>
                                </div>

                            </div>
                        </div>
                    </div>
        </div>
    </main> 
</body>
</html>