// Ejecutar la función cuando se carga la página
window.addEventListener("load", principal);

function principal() {
  var formulario = document.getElementById("formulario");
  formulario.addEventListener("submit", validarTelefono);
  formulario.addEventListener("submit", validarFecha);

  var selectActividad = document.getElementById("actividad_seleccionada");
  selectActividad.addEventListener("change", actualizarNumPersonas);
}

function validarTelefono(event) {
  var telefonoInput = document.getElementById("telefono");
  var telefono = telefonoInput.value.trim();

  // Validar longitud del teléfono
  if (telefono.length !== 9) {
    alert("El número de teléfono debe tener 9 dígitos.");
    event.preventDefault(); // Evitar el envío del formulario
    return;
  }

  // Validar formato del teléfono (debe comenzar con 9 o 6)
  if (!/^[9|6]/.test(telefono)) {
    alert("Número de teléfono no válido. Debe comenzar con 9 o 6.");
    event.preventDefault(); // Evitar el envío del formulario
    return;
  }
}

function validarFecha(event) {
  var fechaInicioInput = document.getElementById("fecha_inicio");
  var fechaInicio = fechaInicioInput.value;

  var fechaFinalInput = document.getElementById("fecha_final");
  var fechaFinal = fechaFinalInput.value;

  // Validar fecha de inicio y fecha final
  if (fechaInicio > fechaFinal) {
    alert("La fecha de inicio no puede ser posterior a la fecha final.");
    event.preventDefault(); // Evitar el envío del formulario
    return;
  }
}

function actualizarNumPersonas() {
  var selectActividad = document.getElementById("actividad_seleccionada");
  var actividadSeleccionada = selectActividad.value;
  var numPersonasInput = document.getElementById("num_personas");

  // Definir un objeto que mapee cada actividad a su número mínimo correspondiente
  var numeroMinimoPorActividad = {
    "Treking de los pastores": 1,
    "Mayadas De Los Pastores Con Pecnorta": 2,
    "Modo de Vida Mayadas de los Pastores": 3,
    "Mayadas De Los Pastores": 4,
    "Praderias De Nava": 5,
    "Jou De Los Cabrones": 6,
    "El Cuetón": 7,
    "Macizo Central Picos Europa": 8,
    "Los Urrieles": 9
  };

  // Obtener el número mínimo correspondiente a la actividad seleccionada
  var numeroMinimo = numeroMinimoPorActividad[actividadSeleccionada];

  // Verificar si el valor introducido es menor al número mínimo
  if (parseInt(numPersonasInput.value) < numeroMinimo) {
    alert("El número mínimo de personas para esta actividad es: " + numeroMinimo);
    numPersonasInput.value = numeroMinimo; // Establecer el valor mínimo en el campo
    event.preventDefault(); // Evitar el envío del formulario
  }
}
