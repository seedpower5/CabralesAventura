// Ejecutar la función cuando se carga la página
window.addEventListener("load", principal);

function principal() {
  var formulario = document.querySelector("form"); // Obtener el formulario
  formulario.addEventListener("submit", validarTelefono);
}

function validarTelefono(event) {
  var telefonoInput = document.getElementById("telefono");
  var telefono = telefonoInput.value.trim();

  // Validar longitud del teléfono
  if (telefono.length !== 9) {
    alert("El número de teléfono debe tener 9 dígitos.");
    event.preventDefault(); // Evitar el envío del formulario
    return;
  }

  // Validar formato del teléfono (debe comenzar con 9 o 6)
  if (!/^[9|6]/.test(telefono)) {
    alert("Número de teléfono no válido. Debe comenzar con 9 o 6.");
    event.preventDefault(); // Evitar el envío del formulario
    return;
  }

  // Habilitar o deshabilitar el botón de envío según la validación del teléfono
  var submitButton = document.querySelector("input[type='submit']");
  if (telefono.length === 9 && /^[9|6]/.test(telefono)) {
    submitButton.disabled = false; // Habilitar el botón de envío
  } else {
    submitButton.disabled = true; // Deshabilitar el botón de envío
  }
}