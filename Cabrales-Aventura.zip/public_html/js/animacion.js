gsap.to('.logo',{
  duration: 1,
  rotation: 360,
  delay: 1,

});
gsap.from('.titulo', 
{
    duration: 3,
    x: 900,
    delay: 1,
    ease: 'bounce.out',
    opacity: 0,
});

gsap.from('.ilustracion',{
  duration: 3,
  opacity: 0,
  delay: 1,
});
gsap.from('.contenedor-sobre-nosotros',{
  duration: 3,
  opacity: 0,
  delay: 1,

});
