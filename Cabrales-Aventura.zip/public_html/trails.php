<!DOCTYPE html>
<html lang="es">
<?php
require_once 'php/Carreras.php';

$carreras = new Carreras();
$listadoCarreras = $carreras->listadoCarreras();

function calcularPlazasDisponibles($carrera) {
    $plazasReservadas = $carrera['plazasReservadas']; // Corregido: 'plazas_reservadas' -> 'plazasReservadas'
    $plazasDisponibles = $carrera['plazasDisponibles']; // Corregido: $plazasDisponibles - $plazasReservadas -> $carrera['plazasDisponibles']
    return $plazasDisponibles;
}
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Cabrales Aventura</title>
    <link rel="shortcut icon" href="./fotos/logos/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/trails.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800&display=swap" rel="stylesheet">
    <script src="./js/contadorPlazas.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/gsap.min.js"></script>
</head>

<body>
    <header>
        <!-- Navegador de la pagina web -->
        <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="index.html">Inicio</a>
            <a class="nav-item nav-link" href="listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="trails.php">Carreras</a>
            <a class="nav-item nav-link" href="php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="php/login.php">Administración</a>
        </nav>
        <!-- Fondo de la pagina web -->
        <div class="fondo d-flex justify-content-center align-items-center flex-column">
        <img class="logo" src="fotos/logos/logo.png" alt="logo" style="border-radius: 50%; width: 8%;">
            <h1>Cabrales Aventura</h1>
            <p>una experiencia única</p>
            <button class="btn btn-primary" onclick="location.href='sobreMi.html'">Sobre mi</button>
        </div>
    </header>
    <div class="container my-5">
        <h2 class="titulo tf">Listado de carreras y trails de montaña</h2>
</div>
<div class="container my-5">
        <h3 class="titulo tf" >Los plazos de inscricion abren el: 17/05/2024</h3>
</div>
<div class="plazas-disponibles">
        <span class="plazas-texto">Plazas disponibles Trail de las Pastoras:</span>
        <span id="contador-plazas" class="plazas-numero">
            <?php echo calcularPlazasDisponibles($listadoCarreras[0]); ?>
        </span>
    </div>
    <div class="plazas-disponibles">
        <span class="plazas-texto">Plazas disponibles Subisomas:</span>
        <span id="contador-plazas" class="plazas-numero">
            <?php echo calcularPlazasDisponibles($listadoCarreras[1]); ?>
        </span>
    </div>
    <div class="plazas-disponibles">
        <span class="plazas-texto">Plazas disponibles Verticales:</span>
        <span id="contador-plazas" class="plazas-numero">
            <?php echo calcularPlazasDisponibles($listadoCarreras[2]); ?>
        </span>
    </div>
<section class="mt-5">
    <div class="container1">
        <div class="row justify-content-center">
        <?php
    foreach ($listadoCarreras as $carrera) {
      echo '<div class="col-12 col-sm-8 col col-md-4 col-lg-3 mt-2">';
      echo '<div class="card" style="width: 18rem;">';
      echo '<img src="fotos/Carreras/'.$carrera['nombre'].'.jpg" class="card-img-top" alt="'.$carrera['nombre'].'">';
      echo '<div class="card-body">';
      echo '<h5 class="card-title">'.$carrera['nombre'].'</h5>';
      echo '<p class="card-text text-justify-flex">'.$carrera['descripcion'].'</p>'; 
      echo '<a href="php/FormularioCarreras.php?reserva='.$carrera['id_carrera'].'" class="btn btn-warning mr-2">Reserva</a>';
      echo '<a class="btn btn-success mr-2">'.$carrera['precio'].'$</a>';
      echo '<a class="btn btn-danger mr-2">'.$carrera['km'].' km</a>';
      echo '</div>'; // cierre div class=card
      echo '</div>';
      echo '</div>';
  }
?>
        </div>
    </div>
</section>
<script src="./js/animacion.js"></script>
<div style="clear:both"></div>
    <footer>
        <div class="contenedor-footer">
            <div class="content-foo">
                <h4>Teléfono</h4>
                <p>985 846 487</p>
            </div>
            <div class="content-foo">
                <h4>Email</h4>
                <p>cabralesaventuras@gmail.com</p>
            </div>
            <div class="content-foo">
                <h4>Localización</h4>
                <p>Arenas de Cabrales</p>
            </div>
        </div>
        <h2 class="titulo-final">© Cabrales Aventura | Todos los derechos reservados </h2>
    </footer>
</body>
</html>