//AJUSTES PARA QUE LA WEB SEA RESPONSIVE

// Ejecutar la función cuando se carga la página
window.addEventListener("load", ocultarElemento)
// Ejecutar la función cuando se redimensiona la ventana
window.addEventListener("resize", ocultarElemento);;

function ocultarElemento() {
 
    //declaracion de avriables
    var localizacion = document.getElementById("localizacion");
    var imagen = document.getElementById("foto-urriellu");
    var opinion = document.getElementsByClassName("contenido-textos opinion")[0];
    var redes = document.getElementsByClassName("contenido-textos redes")[0];
    var categorias=document.getElementsByClassName("clientes contenedor")[0];
  
  // Verificar si es un dispositivo móvil
  if (/Mobi|Android/i.test(navigator.userAgent)) {
    localizacion.style.display = "none";
    imagen.style.display = "none";
    opinion.style.display = "none";
    redes.style.display = "none";
    categorias.style.display = "none";
  } else {
    localizacion.style.display = "block";
    imagen.style.display = "block";
    opinion.style.display = "block";
    redes.style.display = "block";
    categorias.style.display = "block";
  }
  //verifica si tamaño reducido
    if (window.innerWidth <= 768) {
        localizacion.style.display = "none";
        imagen.style.display = "none";
       opinion.style.display = "none";
      redes.style.display = "none";
      categorias.style.display = "none";
    } else {
        localizacion.style.display = "block";
        imagen.style.display = "block";
       opinion.style.display = "block";
      redes.style.display = "block";
      categorias.style.display = "block";
    }
}



