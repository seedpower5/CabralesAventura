<!DOCTYPE html>
<html lang="es">
<?php
    require_once 'php/Actividades.php';
    require_once 'php/Categoria.php';
    // Seleccionar la categoría "Montaña" por defecto
    $defaultCategoria = 1;
    $categoriaSeleccionada = isset($_POST['categoria']) ? $_POST['categoria'] : $defaultCategoria;
?>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <title>Cabrales Aventura</title>
    <link rel="shortcut icon" href="./fotos/logos/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,800&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.6.1/gsap.min.js"></script>
</head>

<body>
    <header>
        <!-- Navegador de la pagina web -->
        <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="index.html">Inicio</a>
            <a class="nav-item nav-link" href="listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="trails.php">Carreras</a>
            <a class="nav-item nav-link" href="php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="php/login.php">Administración</a>
        </nav>
        <!-- Fondo de la pagina web -->
        <div class="fondo d-flex justify-content-center align-items-center flex-column">
        <img class="logo" src="fotos/logos/logo.png" alt="logo" style="border-radius: 50%; width: 8%;">
            <h1>Cabrales Aventura</h1>
            <p>una experiencia única</p>
            <button class="btn btn-primary" onclick="location.href='sobreMi.html'">Sobre mi</button>
        </div>
    </header>
    <section class="mt-5">
    <div class="container">
        <form method="POST" action="listadoActividades.php">
            <div class="form-row align-items-center justify-content-center">
            <div class="col-auto my-1 d-flex align-items-center" style="margin-bottom: -10px;">
    <label class="mr-sm-2" for="categoria"><strong>Seleccione categoria:</strong></label>
    <select class="custom-select mr-sm-2" id="categoria" name="categoria">
    <option value="0">Todas las categorías</option>
    <?php
        $miCategoria = new Categoria();
        $categoria = $miCategoria->listadoCategoriasHabilitadas();
        foreach($categoria as $cat) {
            if ($cat['id_cat'] == 5) {
                continue; // Si la categoría es "Carreras", salta a la siguiente iteración del bucle
            }
            echo "<option";
            echo " value=". $cat['id_cat'];
            if($cat['descripcion'] == 'montaña' || $cat['id_cat'] == $categoriaSeleccionada) {
                echo " selected";
            }
            echo ">".$cat['descripcion'];
            echo "</option>";
        }
    ?>
</select>
    <button name='Filtrar' type="submit" class="btn btn-primary ml-2">Filtrar</button>
    
</div>
</div>
            </div>
        </form>
    </div>
</section>

<section class="mt-5">
    <div class="container1">
        <div class="row justify-content-center">
        <?php
    $miActividad = new Actividades();
    $actividades = $miActividad->seleccionarActividadPorCategoria($categoriaSeleccionada);

    $contador = 0;
    foreach ($actividades as $key => $value) {
        if($contador == 0) {
            echo '<div class="row justify-content-center">';
        }
        echo '<div class="col-12 col-sm-8 col col-md-4 col-lg-3 mt-2">';
        echo '<div class="card" style="width: 18rem;">';
        echo '<img src="fotos/Actividades/'.$value['nombre'].'.png" class="card-img-top" alt="'.$value['nombre'].'" style="width: 100%; height: 200px;">';
        echo '<div class="card-body">';
        echo '<h5 class="card-title">'.$value['nombre'].'</h5>';
        echo '<p class="card-text text-justify-flex">'.$value['descripcion'].'</p>'; 
        echo '<a href="php/Formulario.php?reserva='.$value['id_actividad'].'" class="btn btn-warning mr-2">Reserva</a>';
        echo '<a class="btn btn-success mr-2">'.$value['precio'].'$</a>';
        echo '<a class="btn btn-danger mr-2">'.$value['dificultad'].'</a>';
        echo '</div>'; // cierre div class=card
        echo '</div>';
        echo '</div>';
        if($contador == 2) {
            echo '</div>';
        }
        $contador++;
        if($contador == 3) {
            $contador = 0;
        }
    }
    if($contador != 0) {
        echo '</div>';
    }
?>
        </div>
    </div>
</section>
<script src="./js/animacion.js"></script>
<div style="clear:both"></div>
    <footer>
        <div class="contenedor-footer">
            <div class="content-foo">
                <h4>Teléfono</h4>
                <p>985 846 487</p>
            </div>
            <div class="content-foo">
                <h4>Email</h4>
                <p>cabralesaventuras@gmail.com</p>
            </div>
            <div class="content-foo">
                <h4>Localización</h4>
                <p>Arenas de Cabrales</p>
            </div>
        </div>
        <h2 class="titulo-final">© Cabrales Aventura | Todos los derechos reservados </h2>
    </footer>
</body>
</html>