<?php
session_start();
require_once '../php/Usuario.php';
require_once('../php/Actividades.php');
require_once('../php/Categoria.php');

?>
<html>
<head>
	<title>Crear nueva Ruta</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/formulario.css">
	<link rel="stylesheet" href="../css/w3.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body class="cabecera">
	
		<header >
			  <!-- Navegador de la pagina web -->
      <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="../index.html">Inicio</a>
            <a class="nav-item nav-link" href="../listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="../php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="../php/login.php">Administración</a>
        </nav>
		</header>
		<?php
		
			$miCategoria = new Categoria();

			$categoria=$miCategoria->listadoCategorias();
			//print_r($actividades);
		?>

		<div class="w3-row-padding  w3-margin-top W3-center w3-auto W3-theme-white w3-display-middle  w3-card-4">
			<div class="w3-center">
				<div class=" w3-container contenedor1 " style="min-height:460px">
				<a href="../php/Administracion.php">
    <img class="w3-margin-bottom w3-card w3-circle" src="../fotos/logos/logo.png" alt="logo" width="100" height="100"/>
</a><br>

					<form class="w3-animate-right w3-large "  action="crearRuta.php" method="POST">
						
						 
						<label for="nombre">Nombre:</label>
						<input type="text" name="nombre" id="nombre" required><br><br>
						
						<label for="descripcion">Descripción:</label><br>
						<textarea name="descripcion" id="descripcion" rows="4" cols="50" required></textarea><br><br>
						
						<label for="precio">Precio:</label>
						<input type="number" name="precio" id="precio" required><br><br>
						
						<label for="id_categoria">Categoría:</label>
						<select name="id_categoria" id="id_categoria" required>
								<!-- accemos un foreach que seleccione el nombre de la actividad y lo marque como seleccionado -->
						<?php 
								foreach($categoria as $cat){
								echo "<option";
									
									echo " value=". $cat['id_cat'];
									if($categoria==$cat['descripcion']){echo " selected=selected ";}
								echo">".$cat['descripcion'];
								echo "</option>";
								}
							?>
						</select><br><br>
						
						<label for="dificultad">Dificultad:</label>
						<select name="dificultad" id="dificultad" required>
							<option value="1">Fácil</option>
							<option value="2">Medio</option>
							<option value="3">Difícil</option>
						</select><br><br>
						
						<label for="imagen">Imagen:</label>
						<input type="text" name="imagen" id="imagen" required><br><br>
						
						<input type="submit" name="submit" value="Crear actividad">
					</form>
					
				</div>
			</div>
		</div>	
			<?php
			
if (isset($_POST['submit'])) {
    // Crear un objeto Actividades
    $actividad = new Actividades();

    // Establecer las propiedades de la actividad con los valores del formulario
    $actividad->setNombre($_POST['nombre']);
    $actividad->setDescripcion($_POST['descripcion']);
    $actividad->setPrecio($_POST['precio']);
    $actividad->setId_Categoria($_POST['id_categoria']);
    $actividad->setDificultad($_POST['dificultad']);
    $actividad->setImagen($_POST['imagen']);

    // Crear la actividad en la base de datos
    $actividad->crearActividad();

    // Redirigir al usuario a una página de confirmación o realizar alguna acción adicional si es necesario
    echo "Actividad creada exitosamente.";
}
			?>
	</body>
</html>