<?php
session_start();

// Verificar si la sesión está iniciada
// if (!isset($_SESSION['usuario'])) {
// 	// Si no hay sesión iniciada, redirigir al usuario a la página de inicio de sesión
// 	header("Location: ../php/login.php");
// 	exit();
//   }
  
require_once '../php/Categoria.php';
?>
<html>
<head>
	<title>Crear nueva Usuario</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/formulario.css">
	<link rel="stylesheet" href="../css/w3.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body class="cabecera">
	
		<header >
	
			  <!-- Navegador de la pagina web -->
      <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="../index.html">Inicio</a>
            <a class="nav-item nav-link" href="../listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="../php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="../php/login.php">Administración</a>
        </nav>
		</header>
		<div class="w3-row-padding  w3-margin-top W3-center w3-auto W3-theme-white w3-display-middle  w3-card-4">
			<div class="w3-center">
				<div class=" w3-container contenedor1 " style="min-height:460px">
					<h3 class="w3-xxxlarge w3-animate-left">Crear Nueva Categoria</h3><br>
					<a href="../php/Administracion.php">
    <img class="w3-margin-bottom w3-card w3-circle" src="../fotos/logos/logo.png" alt="logo" width="100" height="100"/>
</a><br>

					<form class="w3-animate-right w3-large "  action="crearCategoria.php" method="POST">
					

						<label for="nombre_usuario">Nombre Categoria:</label><br>
						<input type="text" id="descripcion" class="fadeIn second " name="descripcion" placeholder="Montaña"><br><br>

                        <label for="estado">Estado</label>
						<select name="estado" id="estado" required>
							<option value="0">visible</option>
							<option value="1">no visible</option>
						</select><br><br>

						<input type="submit" name="submit" value="Crear categoria">
					</form>
					
				</div>
			</div>
		</div>
		
		<?php
			if (isset($_POST['submit'])) {
				// Crear un objeto Categoria
				$categoria = new Categoria();
				
				// Establecer las propiedades de la actividad con los valores del formulario
				
				$categoria->setDescripcion($_POST['descripcion']);
				$categoria->setEstado($_POST['estado']);
				// Crear la categoria en la base de datos
				$categoria->crearCategoria();
				
				// Redirigir al usuario a una página de confirmación
				echo"todo ok";
				exit();
			}else
			{
			
			}
		?>
	</body>
</html>