<?php
session_start();
require_once '../php/Categoria.php';

if (isset($_POST['habilitar'])) {
    $categoria = new Categoria();
    $id_cat = $_POST['id_cat'];
    $categoria->habilitarCategoria($id_cat);
    echo "<p>Categoría habilitada correctamente.</p>";
}

$miCategoria = new Categoria();
$categorias = $miCategoria->listadoCategoriasDeshabilitadas();
?>
<html>
<head>
	<title>Deshabilitar Actividades</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/formulario.css">
	<link rel="stylesheet" href="../css/w3.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body class="cabecera">
	
		<header >
			  <!-- Navegador de la pagina web -->
      <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="../index.html">Inicio</a>
            <a class="nav-item nav-link" href="../listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="../php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="../php/login.php">Administración</a>
        </nav>
		</header>
		
		<div class="w3-row-padding  w3-margin-top W3-center w3-auto W3-theme-white w3-display-middle  w3-card-4">
			<div class="w3-center">
				<div class=" w3-container contenedor1 " style="min-height:460px">
					<h1 class="w3-xxxlarge w3-animate-left">habilitar Actividades</h1><br>
					<a href="../php/Administracion.php">
    <img class="w3-margin-bottom w3-card w3-circle" src="../fotos/logos/logo.png" alt="logo" width="100" height="100"/>
</a><br>

					<form class="w3-animate-right w3-large "  action="habilitarCategoria.php" method="POST">
					<div class= "controls">  
						<label>Selecciona Categoria a habilitar</label>
						<select name="id_cat" id="id_cat">
						<?php
							foreach($categorias as $cat) { 
								?>
								<option value="<?php echo $cat['id_cat']; ?>"><?php echo $cat['descripcion']; ?></option>
							<?php 
							} 
							?>
						</select>
					</div>
                <input type="submit" class="fadeIn fourth w3-card-4 " value="habilitar" name="habilitar" style="background-color:#b0db6b">
					</form>
					
				</div>
			</div>
		</div>
	
		
	</body>
</html>