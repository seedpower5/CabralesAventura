<?php
session_start();
require_once '../php/Usuario.php';

?>
<html>
<head>
	<title>Crear nueva Usuario</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/bootstrap.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/formulario.css">
	<link rel="stylesheet" href="../css/w3.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body class="cabecera">
	
		<header >
	
			  <!-- Navegador de la pagina web -->
      <nav class="nav nav-pills nav-fill bg-dark">
            <a class="nav-item nav-link" href="../index.html">Inicio</a>
            <a class="nav-item nav-link" href="../listadoActividades.php">Actividades</a>
            <a class="nav-item nav-link" href="../php/Formulario.php">Reservas</a>
            <a class="nav-item nav-link" href="../php/login.php">Administración</a>
        </nav>
		</header>
		<div class="w3-row-padding  w3-margin-top W3-center w3-auto W3-theme-white w3-display-middle  w3-card-4">
			<div class="w3-center">
				<div class=" w3-container contenedor1 " style="min-height:460px">
					<h1 class="w3-xxxlarge w3-animate-left">Crear Nuevo Usuario</h1><br>
					<a href="../php/Administracion.php">
    <img class="w3-margin-bottom w3-card w3-circle" src="../fotos/logos/logo.png" alt="logo" width="100" height="100"/>
</a><br>

					<form class="w3-animate-right w3-large "  action="crearUsuario.php" method="POST">

						<label for="nombre_usuario">Nombre Usuario:</label><br>
						<input type="text" id="nombre_usuario" class="fadeIn second " name="nombre_usuario" placeholder="Nombre Usuario"><br><br>

                        <label for="contraseña">Contraseña Usuario:</label><br>
						<input type="text" id="pass" class="fadeIn second " name="pass" placeholder="Contrasena Usuario"><br><br>
						<input type="submit" name="submit" value="Crear usuario">
					</form>
					
				</div>
			</div>
		</div>
		
		<?php
			if (isset($_POST['submit'])) {
				// Crear un objeto Actividades
				$usuario = new Usuario();
				
				// Establecer las propiedades de la actividad con los valores del formulario
				$usuario->setId($_POST['nombre_usuario']);
				$usuario->setPass($_POST['pass']);
					
				// Crear la usuario en la base de datos
				$usuario->crearusuario();
				
				// Redirigir al usuario a una página de confirmación
				echo"todo ok";
				exit();
			}else
			{
			
			}
		?>
	</body>
</html>